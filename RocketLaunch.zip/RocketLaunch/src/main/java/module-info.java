module org.example.rocketlaunch {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;
    requires java.net.http;


    opens org.example.rocketlaunch to javafx.fxml, com.google.gson;
    exports org.example.rocketlaunch;
}