package org.example.rocketlaunch;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class LaunchModel {
    private List<Launch> launches;
    private final HttpClient client;
    private final Gson gson;

    public LaunchModel() {
        launches = new ArrayList<>();
        client = HttpClient.newHttpClient();
        gson = new Gson();
    }

    public void fetchLaunches() {
        String url = "https://lldev.thespacedevs.com/2.2.0/launch/upcoming/?limit=10";

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Accept", "application/json")
                .build();

        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new IOException("Unexpected status code: " + response.statusCode());
            }

            String jsonData = response.body();
            JsonObject jsonObject = gson.fromJson(jsonData, JsonObject.class);
            JsonArray results = jsonObject.getAsJsonArray("results");

            launches.clear();
            for (int i = 0; i < results.size(); i++) {
                JsonObject launchJson = results.get(i).getAsJsonObject();
                Launch launch = new Launch(
                        launchJson.get("name").getAsString(),
                        launchJson.get("net").getAsString(),
                        launchJson.getAsJsonObject("pad").getAsJsonObject("location").get("name").getAsString(),
                        launchJson.getAsJsonObject("rocket").getAsJsonObject("configuration").get("name").getAsString()
                );
                launches.add(launch);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            // Handle the error appropriately in your application
        }
    }

    public List<Launch> getLaunches() {
        return launches;
    }
}