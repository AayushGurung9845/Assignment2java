package org.example.rocketlaunch;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class DetailView extends BorderPane {
    private Label nameLabel, dateLabel, locationLabel, rocketLabel;
    private Button backButton;

    public DetailView() {
        initializeComponents();
        layoutComponents();
        styleComponents();
    }

    private void initializeComponents() {
        nameLabel = new Label();
        dateLabel = new Label();
        locationLabel = new Label();
        rocketLabel = new Label();
        backButton = new Button("Back to List");
    }

    private void layoutComponents() {
        VBox detailsBox = new VBox(10,
                new Label("Launch Details:"),
                nameLabel, dateLabel, locationLabel, rocketLabel);
        detailsBox.setPadding(new Insets(20));

        setCenter(detailsBox);
        setBottom(backButton);

        BorderPane.setMargin(backButton, new Insets(10));
        BorderPane.setAlignment(backButton, Pos.CENTER);
    }

    private void styleComponents() {
        setStyle("-fx-background-color: #f0f0f0;");
        backButton.setStyle("-fx-background-color: #008CBA; -fx-text-fill: white;");

        Font labelFont = Font.font("Arial", FontWeight.BOLD, 14);
        nameLabel.setFont(labelFont);
        dateLabel.setFont(labelFont);
        locationLabel.setFont(labelFont);
        rocketLabel.setFont(labelFont);
    }

    public void showLaunchDetails(Launch launch) {
        if (launch != null) {
            nameLabel.setText("Name: " + launch.getName());
            dateLabel.setText("Date: " + launch.getDate());
            locationLabel.setText("Location: " + launch.getLocation());
            rocketLabel.setText("Rocket: " + launch.getRocketName());
        }
    }

    public Button getBackButton() { return backButton; }
}